class APIKeyException(Exception):
    pass
