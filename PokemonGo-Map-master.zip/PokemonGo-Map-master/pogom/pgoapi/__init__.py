from pgoapi      import *


import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()